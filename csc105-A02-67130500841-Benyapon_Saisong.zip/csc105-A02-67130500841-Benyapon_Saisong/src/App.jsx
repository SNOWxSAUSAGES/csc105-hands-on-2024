import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App(){
  
  const Product = [
    {
      id: 1,
      name: 'Apple ',
      price: 29999,
      image: '/product/apple.jpg',
      description: 'Fresh and crisp gray apples from silicon valley.',
      unit: 'each'
    },
    {
      id: 2,
      name: 'Banana ',
      price: 198000000,
      image: '/product/banana.jpg',
      description: 'Just banana with tape.',
      unit: 'each'
    },
    {
      id: 3,
      name: 'Snow Sausage',
      price: 199,
      image: '/product/snows.jpg',
      description: 'import from China with juicy flavor sausage and natural fat.',
      unit: 'each'
    },
    {
      id: 4,
      name: 'Potato',
      price: 9,
      image: '/product/Potato.jpg',
      description: 'It look tried... You need to help it.',
      unit: 'each'
    },
    {
      id: 5,
      name: 'Buff Green Owl',
      price: 299,
      image: '/product/Buff owl.jpg',
      description: 'Super Duolingo : Spanish or Vanish...',
      unit: 'pack'
    },
    {
      id: 6,
      name: 'OREO',
      price: 399,
      image: '/product/Orca.jpg',
      description: 'juicy cookie and soft cream.',
      unit: 'each'
    }
  ];

  //cart
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  //add item
  const addToCart = (fruit) => {
    const existingItem = cart.find(item => item.id === fruit.id);
    
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === fruit.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ...fruit, quantity: 1 }]);
    }
  };

 
  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  // edit number of item
  const updateQuantity = (id, newQuantity) => {
    if (newQuantity < 1) {
      removeFromCart(id);
      return;
    }
    
    setCart(cart.map(item => 
      item.id === id ? { ...item, quantity: newQuantity } : item
    ));
  };
  
  const calculateTotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  return (
    <div>
      <header>
      <h1>C(S)hopee</h1>
      <h2>CS black market supposer by MOBEE</h2>
        <div id = "cart">
          <button onClick={() => setIsCartOpen(!isCartOpen)}>
            <span>{cart.reduce((total, item) => total + item.quantity, 0)}</span>
          </button>
        </div>
      </header>
        {isCartOpen && (
          <div>
            <div id="cart">
                <h2>Your Cart</h2>
                <button onClick={() => setIsCartOpen(false)}>Close</button>
              {cart.length === 0 ? (
                <p>Your cart is empty</p>
                
              ) : (
                <>
                    {cart.map(item => (
                      <div key={item.id} class="item">
                        
                        <img src={item.image} alt={item.name} id="picart"/>
                          <p1> {item.name}  </p1>
                          <p> <button onClick={() => removeFromCart(item.id)}>X</button></p>
                          {item.price.toFixed(2)} per {item.unit}
                            <button onClick={() => updateQuantity(item.id, item.quantity - 1)}>-
                            </button>
                            <span> {item.quantity} </span><button onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
                        
                      </div>
                    ))}
                    <span>Total:</span>
                    <span>{calculateTotal().toFixed(2)}</span>
                    <button>Checkout all Item</button>
                  
                </>
              )}
            </div>
          </div>
        )}
        
          {Product.map(fruit => (
            <div key={fruit.id} id="Good">
              <img src={fruit.image} alt={fruit.name} id="pic"/>
                <h3>{fruit.name}</h3>
                <p>{fruit.description}</p>
                <p class="price">{fruit.price.toFixed(2)} Bath</p>
                <button onClick={() => addToCart(fruit)}>Add to Cart</button>
            </div>
          ))}
      <footer>
        <p id="foot">Free Shippping! - Today only</p>
      </footer>
    </div>
  );
};

export default App
