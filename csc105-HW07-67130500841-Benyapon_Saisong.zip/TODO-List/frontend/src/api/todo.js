//import { Axios } from "../axiosInstance.js";

import axios from 'axios';

const API_URL = 'http://localhost:8000';

export const getTodo = async () => {
  try {
    const response = await axios.get(`${API_URL}/todo`);
    return response.data;
  } catch (error) {
    console.error('Error fetching todos:', error);
    throw error;
  }
};

export const createTodo = async (title) => {
  try {
    const response = await axios.post(`${API_URL}/todo/${title}`);
  } catch (error) {
    console.error('Error creating todo:', error);
    throw error;
  }
};

export const CompleteTodo = async (id) => {
  try {
    const response = await axios.patch(`${API_URL}/todo/${id}`)
  } catch (error) {
    console.error(`Error can't done ${id}:`, error);
    throw error;
  }
};

export const updateTodo = async (id,title) => {
  try {
    const response = await axios.patch(`${API_URL}/todo/${id}/${title}`)
  } catch (error) {
    console.error(`Error can't done ${id}:`, error);
    throw error;
  }
};

export const deleteTodo = async (id) => {
  try {
    const response = await axios.delete(`${API_URL}/todo/${id}`);
  } catch (error) {
    console.error('Error creating todo:', error);
    throw error;
  }
};