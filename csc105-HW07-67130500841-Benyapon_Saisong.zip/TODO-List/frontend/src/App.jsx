import { useState, useEffect } from 'react'
import './index.css'
import { getTodo , createTodo, deleteTodo ,CompleteTodo ,updateTodo} from './api/todo.js'

function App() {
  const [complete, setComplete] = useState(true)
  const [todo, setTodo] = useState([]);
  const [newTodoTitle, setNewTodoTitle] = useState("");

  const fetchTodoData = async () => {
    try {
      const data = await getTodo();
		if (data.success) {
			setTodo(data.data);
		}
    } catch (error) {
      console.error("Error fetching todos:", error);
    }
  };

  useEffect(() => {
    fetchTodoData();
  }, []);

  const handleAddTodo = async () => {
    if (!newTodoTitle.trim()) return;
    try {
      await createTodo(newTodoTitle)
      setNewTodoTitle("");
      fetchTodoData(); // Refresh the list after adding
    } catch (error) {
      console.error("Error adding todo:", error);
    }
  };

  const handleDoneTodo = async (id) => {
    try {
      await CompleteTodo(id)
      fetchTodoData();
    } catch (error) {
      console.error("Error can not done itttttt:", error);
    }
  };

  const handleEditTodo = async (id,name) => {
    const newName = String(prompt("Change title of Todo",name));
    if (newName && newName.trim() !== "" && newName !== name) {
      try {
        await updateTodo(id,newName)
        fetchTodoData();
      } catch (error) {
        console.error("Error can't update title:", error);
      }
    }
  };

  const handleDeleteTodo = async (id) => {
    try {
      await deleteTodo(id)
      fetchTodoData();
    } catch (error) {
      console.error("Error delete todo:", error);
    }
  };

  return (
    <div className="h-screen bg-gradient-to-br from-blue-200 to-indigo-400">
      <div className="bg-black text-2xl text-white px-5 py-2">TODO LIST ?</div>
      <div className="flex flex-col justify-center object-center">
        {/* add todo */}
        <form className="flex flex-row justify-center">
          <div className="border-2 p-3 w-75 mt-10 rounded-lg shadow-xl shadow-blue-400 bg-white">
            <div className="flex flex-col">
              <input
                type="text"
                placeholder="title of todo"
                className="outline-0 pl-2 text-lg text-black font-bold"
                value={newTodoTitle}
                onChange={(e) => setNewTodoTitle(e.target.value)}
              />
            </div>
          </div>
          <button
            className="p-3 border-2 border-black mt-10 items-center rounded-lg ml-5 w-16 bg-gradient-to-tl
            from-cyan-400 to-blue-700 shadow-xl shadow-blue-400
            hover:from-blue-700 hover:to-purple-300 text-white font-bold transition duration-500"
            onClick={handleAddTodo}
          >
            Add
          </button>
        </form>
        
        {/* show todo */}
        <div className="shadow-xl shadow-blue-500 space-y-4 p-5 bg-gradient-to-t from-gray-700 to-gray-200 mt-5 rounded-lg w-96 max-h-180 overflow-y-auto mx-auto">
          {todo.length > 0 ? (
            todo.map((todo) => (
              <div
                key={todo.id}
                className={`${
                  todo.success
                    ? "bg-gradient-to-r from-white to-green-300 py-2 pl-3 rounded-lg"
                    : "bg-gradient-to-r from-white to-red-300 py-2 pl-3 rounded-lg"
                }`}
              >
                <div className="flex flex-row justify-between">
                  <div className="flex flex-row justify-start">
                    { todo.success ?(
                  <button
                      onClick={() => handleDeleteTodo(todo.id)}
                      className="h-10 w-10 my-auto border-1 border-black bg-green-500 text-white font-bold text-center
                      text-xs rounded-lg
                       hover:bg-white hover:text-green-500 duration-300 transition"
                    >
                    +5 THB
                    </button>) 
                    : (
                    <button
                    onClick={() => handleDoneTodo(todo.id)}
                    className="bg-red-700 h-10 w-10 my-auto border-1 border-black bg-white text-green-500 font-bold text-center
                    text-xs rounded-lg
                     hover:bg-green-500 hover:text-white duration-300 transition"
                  >
                  Finish
                  </button>  
                    )
                    }       
                  <div className="break-words max-w-xs w-39 p-1.5 font-bold px-3">
                    {todo.name}
                  </div>
                  </div>
                  <div className="flex flex-row justify-end mr-2">
                    <button
                      onClick={() => handleEditTodo(todo.id,todo.name)}
                      className="bg-gray-700 h-10 w-16 my-auto text-white font-bold text-center rounded-lg
                      hover:text-white hover:bg-gray-500 duration-300 transition"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteTodo(todo.id)}
                      className="bg-red-700 h-10 w-10 my-auto ml-2 text-white font-bold text-center rounded-lg
                      hover:text-white hover:bg-red-500 duration-300 transition"
                    >
                      X
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-4 text-white">
              You don't have any todo now
              (free time?)
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App