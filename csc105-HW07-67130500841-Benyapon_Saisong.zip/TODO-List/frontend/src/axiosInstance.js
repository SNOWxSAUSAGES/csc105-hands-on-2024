//I didn't use this because of error it frontend
import axios from 'axios';

const Axios = axios.create({
	baseURL: 'http://localhost:8000', 
});

export { Axios };