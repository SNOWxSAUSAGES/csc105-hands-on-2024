import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { PrismaClient } from "./generated/prisma/index.js";
import { logger } from "hono/logger";
import { cors } from 'hono/cors';
import { mainRouter } from "./router/index.routes.ts";

const app = new Hono();

app.use(
  cors({
    origin: ["http://localhost:5173"], // Your frontend application
  })
);

export const db = new PrismaClient();

app.use(logger());

app.get("/", (c) => {
  return c.text("if you see this msg mean it not work");
});

app.route("", mainRouter);

serve(
  {
    fetch: app.fetch,
    port: 8000,
  },
  (info) => {
    console.log(`Server is running on http://localhost:${info.port}`);
  }
);

db.$connect()
	.then(() => {
		console.log("Connected to the database");
	})
	.catch((error) => {
		console.error("Error connecting to the database:", error);
	});
