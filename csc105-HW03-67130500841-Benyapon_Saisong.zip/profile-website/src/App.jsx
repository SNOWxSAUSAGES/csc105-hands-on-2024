import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { NavLink, Outlet } from "react-router-dom";
import { Link, useNavigate } from "react-router-dom";
import './App.css'
import Home from "./pages/home";
import Gallery from "./pages/gallery";
import AboutMe from "./pages/aboutme";

function App() {
  return (
    <>
    <div className='py-3 bg-black font-bold contain-content  text-white'>
      <div className='float-left px-4'> Benyapon Saisong </div>
      <div className='float-right px-4'>
        <nav className=''>
            <NavLink to="/home" end className='px-4'> Home </NavLink>
            <NavLink to="/aboutme" className='px-4'> About </NavLink>
            <NavLink to="/gallery" className='px-4'> My Gallery </NavLink>
            <div className='float-right px-5 rounded-4xl bg-white  text-black'>
            <Link to="https://www.sit.kmutt.ac.th/">
                  <button> Contact </button>
            </Link>
          </div>
        </nav>
      </div>  
    </div> 
      <Outlet />
    </>
  );
}

export default App
