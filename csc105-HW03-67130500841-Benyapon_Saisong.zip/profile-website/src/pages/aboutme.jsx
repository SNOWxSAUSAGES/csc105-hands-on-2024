import React from 'react';
import { Link, useNavigate } from "react-router-dom";


const aboutme = () => {
  return (
    <div className='my-20  '>
        <div className='contain-content'>
            <div className='place-items-center'>
                <div className='place-items-center'>
                    <img src='src/image/eBEW2.jpg' className=' my-10 object-cover w-100 h-100 rounded-3xl'></img>
                </div>
                <div className=" w-100 m-15 text-left contain-content">
                    <h1 className='text-4xl font-bold'> About me</h1>
                    <p className='text-lg py-2 font-bold'>Pro gamer</p>
                    <p className=''>CS is from "Computer Suffer" I'm master of K-drama.</p>
                    <Link to="https://youtu.be/dQw4w9WgXcQ?si=xyNTp0XWsSIfbVgR">
                            <button className='text-lg p-3 px-8 rounded-2xl bg-gray-700 text-gray-200 font-bold m-3'> Read more </button>
                    </Link>
                </div>
            </div>
            </div>
        </div>
  );
};

export default aboutme;