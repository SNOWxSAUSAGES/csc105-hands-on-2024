import React from 'react';
import { Link, useNavigate } from "react-router-dom";

const Home = () => {
  return (
    <div className='my-20 place-items-center '>
        <div className='flex flex-row'>
        <div className="float w-100 m-15 text-left contain-content">
            <p className='text-10px'>Hello, it'me mario</p>
            <h1 className='text-3xl font-bold'> Benyapon Saisong </h1>
            <p className='text-lg py-2 font-bold'>I'm Seafood lover.</p>
            <p className=''>I am going to do everything accept "Coding".</p>
            <p className=''>My favorite food is Seafood with Seafood sauce</p>
            <div className='my-5 flex flex-row'>
            <Link to="https://www.facebook.com/benyapon.bewwer">
                    <img src='src/icons/FBicon.png' className='rounded-xl mr-4 w-15 h-15 object-cover'></img>
            </Link>
            <Link to="https://www.instagram.com/">
                    <img src='src/icons/IGicon.jpg' className='rounded-xl mr-4 w-15 h-15 object-cover'></img>
            </Link>
            <Link to="https://mail.google.com/mail/u/0/#label/%5BImap%5D%2FDrafts">
                    <img src='src/icons/EMAILicon.png' className='rounded-xl  mr-4 w-15 h-15 object-cover'></img>
            </Link>
            </div>
            <Link to="https://www.canva.com/design/DAFi-bM_j8g/IpEFQHrKybCdLf-rshPwkw/edit?utm_content=DAFi-bM_j8g&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton">
                    <button className='text-lg p-3 px-8 rounded-2xl bg-gray-700 text-gray-200 font-bold m-3'> My Portfolio </button>
            </Link>
           
        </div>
        <div>
            <img src='src/image/eBEW1.jpg' className='my-10 object-cover h-100 rounded-3xl'></img>
        </div>
        </div>
    </div>
  );
};

export default Home;
