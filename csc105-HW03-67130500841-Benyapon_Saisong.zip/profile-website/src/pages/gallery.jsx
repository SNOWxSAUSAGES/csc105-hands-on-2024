import React from 'react';
import { Link, useNavigate } from "react-router-dom";

const Gallery = () => {
    return(
    <div className='my-5  place-items-center'>
        <div className="place-items-center m-15 text-left contain-content">
            <h1 className='text-white text-4xl font-bold rounded-2xl px-15 py-5 bg-gradient-to-r from-cyan-500 to-purple-800'>MY GALLERY ?</h1>
            <p className='my-5'>Click on each picture!</p>
        </div>
        <div className='flex flex-col'>
            <div>
                <div className='flex flex-row'>
                <Link to="https://youtu.be/ML9E33z2jJ0?si=8KJkBuE7gw53wV7e">
                    <div className=''>
                        <img src='src/image/G1.jpg' className='border-cyan-400 border-4 mx-10 object-cover w-70 h-70 rounded-2xl'></img>
                    </div>
                </Link>
                <Link to="https://www.netflix.com/th-en/title/81365087">
                    <div className=''>
                        <img src='src/image/G2.JPG' className='border-blue-500 border-4 mx-10 object-cover w-70 h-70 rounded-2xl'></img>
                    </div>
                </Link>
                <Link to="https://youtu.be/D5j-LKytq1M?si=XfuC_DOJOYdoJOEU">
                    <div className=''>
                        <img src='src/image/G3.JPG' className='border-purple-500 border-4 mx-10 object-cover w-70 h-70 rounded-2xl'></img>
                    </div>
                </Link>
                </div>
            </div>
            <div>
                <Link to="https://www.highziumstudio.com/%EC%95%84%ED%8B%B0%EC%8A%A4%ED%8A%B8/%EC%86%A1%EC%A4%91%EA%B8%B0/">
                <div className=' flex flex-row'>
                    <div className=''>
                        <img src='src/image/G4.JPG' className='border-cyan-400 border-4 m-10 object-cover w-70 h-70 rounded-2xl'></img>
                    </div>
                    <div className=''>
                        <img src='src/image/G5.JPG' className='border-blue-500 border-4 m-10 object-cover w-70 h-70 rounded-2xl'></img>
                    </div>
                    <div className=''>
                        <img src='src/image/G6.JPG' className='border-purple-500 border-4 m-10 object-cover w-70 h-70 rounded-2xl'></img>
                    </div>
                </div>
                </Link>
            </div>
        </div>
    </div>
    );
};

/*<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {images.map((image) => (
            <div key={image.id} className="...">
              <img 
                src={image.src} 
                alt={image.alt} 
              />
            </div>
          ))}
        </div>*/

export default Gallery;
