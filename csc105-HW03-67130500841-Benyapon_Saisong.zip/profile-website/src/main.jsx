import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from "react-router-dom"; //import these modules
import './index.css'
import App from './App.jsx'
import Aboutme from "./pages/aboutme.jsx";
import Home from "./pages/home.jsx";
import Gallery from "./pages/gallery.jsx";


const router = createBrowserRouter([
  {
    path: "/", // Home route
    element: <App />, // Render the App component
    children: [
      {
        path: "/home", // Nested route for About
        element: <Home />,
      },
      {
        path: "/aboutme", // Nested route for About
        element: <Aboutme />,
      },
      {
        path: "/gallery", // Nested route for About
        element: <Gallery />,
      },
    ],
  },
  
]);
createRoot(document.getElementById("root")).render(
  <StrictMode>
    <RouterProvider router={router} /> {/* Provide the router to the app */}
  </StrictMode>
);
