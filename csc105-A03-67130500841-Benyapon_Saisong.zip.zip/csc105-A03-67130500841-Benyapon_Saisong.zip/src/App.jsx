import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState("");

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const add = () => {
    setResult((prev) => prev + Number(input));
    setInput("");
  };

  const subtract = () => {
    setResult((prev) => prev - Number(input));
    setInput("");
  };

  const multiply = () => {
    setResult((prev) => prev * Number(input));
    setInput("");
  };

  const divide = () => {
      setResult((prev) => prev / Number(input));
      setInput("");
  };

  const resetInput = () => {
    setInput("");
  };

  const resetResult = () => {
    setResult(0);
  };

  return (
    <div>
      <h1>A Simple Calculator</h1>
      <p id="p1">Your brain is better than this calculater trust me bro...</p>
      <p>Result : {result}</p>
      <input id="innum" type="number" value={input} onChange={handleInputChange}
      placeholder="Enter a input number"/><br></br>

        <button onClick={add} class="but">Add</button>
        <button onClick={subtract} class="but">Subtract</button>
        <button onClick={multiply} class="but">Multiply</button>
        <button onClick={divide} class="but" >Divide</button>
        <br></br>
        <button onClick={resetInput} class="sbut">Reset Input</button>
        <button onClick={resetResult} class="sbut">Reset Result</button>
      
    </div>
  );
} 
  
export default App
