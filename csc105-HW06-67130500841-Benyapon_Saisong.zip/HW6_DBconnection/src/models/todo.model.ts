import { db } from "../index.ts";

const createTodo = async (title: string, userId: number) => {
    const todo = await db.todo.create({
        data: {
            title: title,
            userId: userId,
        },
    });
    return todo;
}
const getTodo = async (Uid:number,id: number) => {
    const todo = await db.todo.findUnique({
         where: {
            id: id,
            userId : Uid,
        },
    });
    return todo;
}

const GetAllTodo =  async (uid : number) => {
  const todo = await db.todo.findMany({
    where:{
      userId : uid,
    }
    
  });
  return todo;
};

const EditTodo = async (todoId: number, editTodoName: string) => {
    //patch
    const todo = await db.todo.update({
      where: {
        id: todoId,
      },
      data: {
        title: editTodoName,
      },
    });
    return todo;
  };
  const doneTodo = async (todoId: number) => {
    const todo = await db.todo.update({
      where: {
        id: todoId
      },
      data:{
        completed: true,
      },
    });
    return todo;
  };
const deleteTodo = async (id: number) => {
    const todo = await db.todo.delete({
        where: {
            id: id,
        },
    });
    return todo;
}
export { createTodo , getTodo , deleteTodo , doneTodo ,EditTodo,GetAllTodo};