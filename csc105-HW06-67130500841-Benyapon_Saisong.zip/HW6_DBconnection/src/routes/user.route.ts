import { Hono } from "hono";
import * as userController from "../controllers/user.controller.ts";
import { todoRouter } from "./todo.route.ts";

const userRouter = new Hono();

userRouter.post("/:fname/:lname", userController.createUser);
userRouter.get("/", userController.GetAllUser);
userRouter.get("/:id", userController.getuser);
userRouter.patch("/:id/:fname/:lname", userController.Editusername);


export { userRouter };