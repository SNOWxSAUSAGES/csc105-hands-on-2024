import { Hono } from "hono";
import * as todoController from "../controllers/todo.controller.ts";


const todoRouter = new Hono();
todoRouter.post("/:uid/:title", todoController.createTodo);
todoRouter.get("/:uid", todoController.getAllTodo);
todoRouter.get("/:uid/:id", todoController.getTodo);
todoRouter.patch("/:uid/:id/:name", todoController.EditTodoName );
todoRouter.patch("/:uid/:id", todoController.CompleteTodo );
todoRouter.delete("/:id", todoController.deleteTodo);

export { todoRouter };