import type { Context } from "hono";
import * as userModel from "../models/user.model.ts";
//import { Param } from "@prisma/client/runtime/library";

type createUserBody = {
	firstName: string;
	lastName: string;
};
const createUser = async (c: Context) => {
	try {
		const fname = await c.req.param('fname');
		const lname = await c.req.param('lname');
		if (!fname || !lname)
			return c.json(
				{
					success: false,
					data: null,
					msg: "pls enter name? ",
				},
				400
			);
		if (await userModel.isDuplicate(fname, lname)) {
			return c.json({
				success: false,
				data: null,
				msg: "firstName or lastName is duplicated",
			});
		}
		const newUser = await userModel.createUser(
			fname,
			lname
		);
		return c.json({
			success: true,
			data: newUser,
			msg: "Created new User!",
		});
	} catch (e) {
		return c.json(
			{
				success: false,
				data: null,
				msg: `${e}`,
			},
			500
		);
	}
};

const GetAllUser = async (c: Context) => {
	try {
	  const alluser = await userModel.getAllUser();
		  return c.json({
			  success: true,
			  data: alluser,
			  msg: "All user is here!",
		  });
	} catch (e) {
	  return c.json(
		{
		  success: false,
		  data: null,
		  msg: `Internal Server Error : ${e}`,
		},
		500
	  );
	}
  };
const getuser = async (c: Context) => {
	try {
		const id = c.req.param("id");
		if (id !== undefined && id !== null) {
			const data = await userModel.getUser(parseInt(id));
			return c.json(data, 200);
		}
		return c.json(
			{
				success: false,
				data: null,
				msg: "user not found",
			},
			400
		);
	}
	catch (e) {
		return c.json(
			{
				success: false,
				data: null,
				msg: `${e}`,
			},
			500
		);
	}
}
const Editusername = async (c: Context) => {
	try {
	  const newfname = await c.req.param('fname');
	  const newlname = await c.req.param('lname');
	  const idQuery = await c.req.param('id');
	  if (!idQuery) {
		  return c.json({ error: "User not found" }, 404);
	  }
	  const Edit = userModel.EditUsername(parseInt(idQuery),String(newfname),String(newlname));
	  return c.json({
		success: true,
		data: Edit,
		msg: "Change name success",
	});
	} catch (e) {
	  return c.json(
		{
		  success: false,
		  data: null,
		  msg: `Internal Server Error : ${e}`,
		},
		500
	  );
	}
  };
export { createUser,Editusername,getuser,GetAllUser };