import type { Context } from "hono";
import * as todoModel from "../models/todo.model.ts";

type createTodoBody = {
    title: string;
    userId: number;
};

const createTodo = async (c: Context) => {
    try {
        const title = await c.req.param('title');
        const uid = await c.req.param('uid');
        
		if (!title || !uid)
			return c.json(
				{
					success: false,
					data: null,
					msg: "pls write you name",
				},
				400
			);
		const newTodo = await todoModel.createTodo(
		   title,parseInt(uid)
		);
		return c.json({
			success: true,
			data: newTodo,
			msg: "Created new todo!",
    });
    } catch (e) {
        return c.json(
            {
                success: false,
                data: null,
                msg: `${e}`,
            },
            500
        );
    }
}
const getTodo = async (c: Context) => {
    try {
        const param = c.req.param("id");
        const uid = await c.req.param('uid');
        if(param !== undefined && param !== null && uid !== undefined && uid !== null) {
            const data = await todoModel.getTodo(Number(uid),parseInt(param));
            return c.json(data, 200);
        }
        return c.json(
            {
                success: false,
                data: null,
                msg: "Todo not found",
            },
            400
        );
    }
    catch (e) {
        return c.json(
            {
                success: false,
                data: null,
                msg: `${e}`,
            },
            500
        );
    }
}

const getAllTodo = async (c: Context) => {
    try {
        const param = c.req.param("uid");
        if (param !== undefined && param !== null) {
            const data = await todoModel.GetAllTodo(parseInt(param));
            return c.json(data, 200);
        }
        return c.json(
            {
                success: false,
                data: null,
                msg: "Todo not found",
            },
            400
        );
    }
    catch (e) {
        return c.json(
            {
                success: false,
                data: null,
                msg: `${e}`,
            },
            500
        );
    }
}
const EditTodoName = async (c: Context) => {
    try {
      const newname = await c.req.param('name');
      const idQuery = await c.req.param('id');
      if (!idQuery) {
          return c.json({ error: "Todo not found" }, 404);
      }
      // const input = c.get('todoData') as UpdateTodoInput;
      const Edit = todoModel.EditTodo(
        parseInt(idQuery),String(newname));
      return c.json(Edit);
    } catch (e) {
      return c.json(
        {
          success: false,
          data: null,
          msg: `Internal Server Error : ${e}`,
        },
        500
      );
    }
  };

  const CompleteTodo = async (c: Context) => { 
    try {
      const idQuery = await c.req.param('id');
        if (!idQuery) {
          return c.json({ error: "Todo id is required" }, 404);
        }
        const ComTodo = await todoModel.doneTodo(Number(idQuery));
         
        return c.json({
          messsage: 'You todo is Complete - Reward : 1 bath',
          data: ComTodo
        })
    } catch (e) {
  
      return c.json(
        {
          success: false,
          data: null,
          msg: `Internal Server Error : ${e}`,
        },
        500
      );
    }
  };
const deleteTodo = async (c: Context) => {
    try {
        const id = c.req.param("id");
        if (id !== undefined && id !== null) {
            const data = await todoModel.deleteTodo(parseInt(id));
            return c.json(data, 200);
        }
        return c.json(
            {
                success: false,
                data: null,
                msg: "Missing required fields",
            },
            400
        );
    }
    catch (e) {
        return c.json(
            {
                success: false,
                data: null,
                msg: `${e}`,
            },
            500
        );
    }
}
export { createTodo , getTodo,EditTodoName,CompleteTodo,deleteTodo,getAllTodo};