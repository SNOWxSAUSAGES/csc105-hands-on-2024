import React from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Navbar from './components/Navbar'

function App() {
  const location = useLocation()
  
  // List of routes where Navbar should not be shown
  const hiddenNavbarRoutes = ['/login', '/signup']
  
  return (
    <div>
      {!hiddenNavbarRoutes.includes(location.pathname) && <Navbar />}
      <Outlet />
    </div>
  )
}

export default App