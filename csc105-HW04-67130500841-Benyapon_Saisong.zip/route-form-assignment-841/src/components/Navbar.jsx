import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-black p-4">
      <div className="flex justify-between items-center">
        <div className="space-x-10">
          <NavLink 
            to="/" 
            className={({ isActive }) => 
              `text-white ${isActive ? 'font-extrabold' : ''}`
            }
          >
            Home
          </NavLink>
          <NavLink 
            to="/login" 
            className={({ isActive }) => 
              `text-white ${isActive ? 'font-extrabold' : ''}`
            }
          >
            Login
          </NavLink>
          <NavLink 
            to="/fav" 
            className={({ isActive }) => 
              `text-white ${isActive ? 'font-extrabold' : ''}`
            }
          >
            Favourites
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;