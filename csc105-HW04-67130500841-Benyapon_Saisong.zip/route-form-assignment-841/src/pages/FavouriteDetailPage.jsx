import React from 'react'
import { useParams, useSearchParams } from 'react-router-dom'

const FavouriteDetailPage = () => {
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  
  const query = searchParams.get('q')
  const size = searchParams.get('size')

  return (
    <div className="container mx-auto mt-10 text-center">
      <h1 className="text-3xl font-bold mb-4">Favourite Details</h1>
      <p>Your favourite post is {query}.</p>
      <p>Post ID is {id}.</p>
      <p>Size is {size}.</p>
    </div>
  )
}

export default FavouriteDetailPage