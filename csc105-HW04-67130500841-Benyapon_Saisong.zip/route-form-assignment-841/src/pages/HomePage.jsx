import React from 'react';
import Navbar from '../components/Navbar.jsx';

const HomePage = () => {
    return (
        <div>
         
          <div className="container mx-auto p-10">
            <h1 className="text-3xl font-bold text-center bg-gradient-to-l from-blue-500 to-purple-500  rounded-xl text-white p-10">Bruh Home page</h1>
          </div>
        </div>
      );
};

export default HomePage;