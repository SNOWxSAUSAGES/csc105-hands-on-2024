import React from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate } from 'react-router-dom'

// Zod schema for form validation
const favouritesSchema = z.object({
  number: z.number().min(1, 'Number must be between 1 and 100').max(100, 'Number must be between 1 and 100'),
  query: z.enum(['love', 'like'], 'Must select either love or like'),
  size: z.enum(['small', 'medium', 'large'], 'Must select a size')
})

const FavouritesPage = () => {
  const navigate = useNavigate()
  const { 
    register, 
    handleSubmit, 
    formState: { errors } 
  } = useForm({
    resolver: zodResolver(favouritesSchema)
  })

  const onSubmit = (data) => {
    // Navigate to favourite detail page with parameters
    navigate(`/fav/${data.number}?q=${data.query}&size=${data.size}`)
  }

  return (
    <div className="container mx-auto mt-10 max-w-md">
      <h1 className="text-2xl font-bold mb-6 text-center">This is the Favourites Page</h1>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <input 
            type="number" 
            placeholder="Number (1-100)" 
            {...register('number', { valueAsNumber: true })}
            className="w-full p-2 border rounded"
          />
          {errors.number && (
            <p className="text-red-500 text-sm mt-1">
              {errors.number.message}
            </p>
          )}
        </div>
        
        <div>
          <label className="block mb-2">Query:</label>
          <div className="flex space-x-4">
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                value="love" 
                {...register('query')}
                className="form-radio"
              />
              <span className="ml-2">Love</span>
            </label>
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                value="like" 
                {...register('query')}
                className="form-radio"
              />
              <span className="ml-2">Like</span>
            </label>
          </div>
          {errors.query && (
            <p className="text-red-500 text-sm mt-1">
              {errors.query.message}
            </p>
          )}
        </div>
        
        <div>
          <label className="block mb-2">Size:</label>
          <div className="flex space-x-4">
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                value="small" 
                {...register('size')}
                className="form-radio"
              />
              <span className="ml-2">Small</span>
            </label>
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                value="medium" 
                {...register('size')}
                className="form-radio"
              />
              <span className="ml-2">Medium</span>
            </label>
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                value="large" 
                {...register('size')}
                className="form-radio"
              />
              <span className="ml-2">Large</span>
            </label>
          </div>
          {errors.size && (
            <p className="text-red-500 text-sm mt-1">
              {errors.size.message}
            </p>
          )}
        </div>
        
        <button 
          type="submit" 
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
        >
          Submit
        </button>
      </form>
    </div>
  )
}

export default FavouritesPage