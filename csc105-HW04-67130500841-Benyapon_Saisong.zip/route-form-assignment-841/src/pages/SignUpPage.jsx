import React from 'react'
import { NavLink } from 'react-router-dom';

const SignUpPage = () => {
  return (
    <div className="container mx-auto mt-10 text-center">
      <h1 className="text-3xl font-bold">SignUp Page</h1>
      <NavLink to="/" >
          <button className='mt-10 bg-gradient-to-l from-purple-500 to-blue-500 text-white px-5 py-2 rounded-lg font-bold'>Back to Home</button>
      </NavLink>
    </div>
  )
}

export default SignUpPage