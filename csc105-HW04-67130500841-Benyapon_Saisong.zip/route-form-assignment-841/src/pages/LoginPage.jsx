import React from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate, Link } from 'react-router-dom'

// Zod schema for form validation
const loginSchema = z.object({
  email: z.string().email('I dont think email it would be like this '),
  password: z.string().min(6, 'Bro at least 6 character long na...')
})

const LoginPage = () => {
  const navigate = useNavigate()
  const { 
    register, 
    handleSubmit, 
    formState: { errors } 
  } = useForm({
    resolver: zodResolver(loginSchema)
  })

  const onSubmit = (data) => {
    console.log(data)
    navigate('/')
  }

  return (
    <div className="container mx-auto mt-10 max-w-md">
      <h1 className="text-2xl font-bold mb-6 text-center">Login</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <input 
            type="email" 
            placeholder="Email" 
            {...register('email')}
            className="w-full p-2 border rounded"
          />
          {errors.email && (
            <p className="text-red-500 text-sm mt-1">
              {errors.email.message}
            </p>
          )}
        </div>
        
        <div>
          <input 
            type="password" 
            placeholder="Password" 
            {...register('password')}
            className="w-full p-2 border rounded"
          />
          {errors.password && (
            <p className="text-red-500 text-sm mt-1">
              {errors.password.message}
            </p>
          )}
        </div>
        
        <button 
          type="submit" 
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
        >
          Login
        </button>
      </form>
      
      <div className="text-center mt-4">
        <Link 
          to="/signup" 
          className="text-blue-500 hover:font-bold"
        >
          Don't have an account? ( Sign Up )
        </Link>
      </div>
    </div>
  )
}

export default LoginPage